export class Principal {
    userId: number;
    username: string;
    role:string;
    firstName:string;
    lastName:string;
    accountNonLocked:boolean
}
