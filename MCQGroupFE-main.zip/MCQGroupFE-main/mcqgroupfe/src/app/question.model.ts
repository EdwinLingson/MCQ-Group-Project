export interface Question {
    qnNo: number;
    question: string;
    opt1: string;
    opt2: string;
    opt3: string;
    opt4: string;
    correctAnswer: number;
    topicId: number;
  }