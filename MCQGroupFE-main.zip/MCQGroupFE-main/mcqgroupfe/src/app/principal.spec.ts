import { Principal } from './principal';

describe('Principal', () => {
  it('should create an instance', () => {
    expect(new Principal()).toBeTruthy();
  });
});
