export class User {
    userId:number
    username:string
    password:string
    email:string;	
	firstName:string;
	lastName:string;
    user:UserCred
	
}
export class UserCred{
    username:string
    password:string
}
