import { Principal } from "./principal"

export class Credentials {
    principal:Principal
    username:string
    password:string

}
